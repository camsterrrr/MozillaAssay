# Themes: Animated

## What it does

Employs an animated PNG image as the theme_frame image in a theme.

## What it shows

How to use an animated image in a theme.
